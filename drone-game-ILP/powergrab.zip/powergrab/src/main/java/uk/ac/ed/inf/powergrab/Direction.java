package uk.ac.ed.inf.powergrab;

public enum Direction {
	/*
	 * This is a class of all the directions the drone can go in.
	 */
	N,NNE,NE,ENE,E,ESE,SE,SSE,S,SSW,SW,
	WSW,W,WNW,NW,NNW
}

